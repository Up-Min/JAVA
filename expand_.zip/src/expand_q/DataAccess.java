package expand_q;

public interface DataAccess {
	void time();
	void sales();
	void vipwating();
}
